using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ��Ʈ���޽��� : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        string message = "�輼��";

        Debug.Log(message + "!");
        Debug.Log(message[1]);
        Debug.Log(message[0]);
        Debug.Log(message[2]);

        Debug.Log("�輼��"[1]);
        Debug.Log("�輼��"[0]);
        Debug.Log("�輼��"[2]);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
