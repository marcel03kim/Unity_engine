using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class 복합대입연산자 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        string output = "김세현";
        output += "2024";
        output += "137009";
        Debug.Log(output);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
