using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class 바활용 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        var numberA = 100; //int자료형
        var numberB = 130L; //Long 자료형
        var numberC = 343.0; //double 자료형
        var numberD = 587.0F; //float 자료형
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
