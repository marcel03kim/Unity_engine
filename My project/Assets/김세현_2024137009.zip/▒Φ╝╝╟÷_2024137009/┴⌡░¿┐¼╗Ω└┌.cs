using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class 증감연산자 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int number = 10;
        number++;
        Debug.Log(number);
        number--;
        Debug.Log(number);
        number++;
        Debug.Log(number);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
